Processing


Question

   |
   |
  \ /

Get year, strip from question (simple search?) yes

   |
   |
  \ /


Is team question or season question (make classification, if lacking confidence, ask question explicity)


   |																			 |
   |																		     |
  \ /																			\ /

Given team, question classifier for team question 				Given overall, classifier for season questions


   |																			 |
   |																		     |
  \ /																			\ /



							Output all messages above a certain threshhold
									(and simple aggregation) (, and)